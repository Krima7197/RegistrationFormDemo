

import UIKit

class first: UIViewController {

    @IBOutlet weak var lbl: UILabel!
    
    @IBOutlet weak var lbldob: UILabel!
    @IBOutlet weak var lblpass: UILabel!
    @IBOutlet weak var lblmail: UILabel!
    @IBOutlet weak var lblmno: UILabel!
    
    
    var name = ""
    var mno = ""
    var mail = ""
    var pass = ""
    var dob = ""
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        lbl.text = name
        lblmno.text = mno
        lblmail.text = mail
        lblpass.text = pass
        lbldob.text = dob
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    

}
